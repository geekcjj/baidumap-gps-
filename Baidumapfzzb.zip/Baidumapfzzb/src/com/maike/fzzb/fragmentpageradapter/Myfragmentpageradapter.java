package com.maike.fzzb.fragmentpageradapter;

import java.util.ArrayList;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class Myfragmentpageradapter extends FragmentStatePagerAdapter {
	ArrayList<Fragment> list;

	public Myfragmentpageradapter(FragmentManager fm, ArrayList<Fragment> list) {
		super(fm);
		this.list = list;

	}

	public int getCount() {
		return list.size();
	}

	public Fragment getItem(int arg0) {
		return list.get(arg0);
	}
}
