package com.maike.baidumapfzzb;

import com.maike.baidumapfzzb.application.MyApplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.DhcpInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class BaidumapActivity extends Activity implements OnClickListener{
	private static final String TAG = "BadumapActivity";
	//��������ϵ�һ�����Ͱ�ť
	Button send;
	Button map;
	Handler handler;
	//�����������ͨ�ŵ����߳�
	ClientThread clientThread;
	private WifiManager wifiManager;
	int serverAddress;
	public static String ip;
	private TextView iptxt;
	Button ipshow;
	private String str="";
	private String[] gpsm=null;
    private String gpsstr="";
    private MyApplication myapp;
	private Button openwifi;
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.baidumapactivity);
		send=(Button)findViewById(R.id.sendbtn);
		iptxt=(TextView)findViewById(R.id.iptxt);
		ipshow=(Button)findViewById(R.id.ipshow);
		openwifi=(Button)findViewById(R.id.wifi);
		map=(Button)findViewById(R.id.map);
		send.setOnClickListener(this);
		ipshow.setOnClickListener(this);
		openwifi.setOnClickListener(this);
		map.setOnClickListener(this);
        myapp=(MyApplication)getApplication();
        myapp.setIp(ip);
	}
	private String intToIp(int serverAddress) {
		// TODO Auto-generated method stub
		return (serverAddress & 0xFF) + "." +
        ((serverAddress >> 8) & 0xFF) + "." +
        ((serverAddress >> 16) & 0xFF) + "." +
        (serverAddress >> 24 & 0xFF);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.ipshow:
			iptxt.setText(ip);
			break;
		case R.id.wifi:
			//��ȡWiFi����
	        wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
	        //�ж�WiFi�Ƿ���
	        if (!wifiManager.isWifiEnabled()) {
	            Toast.makeText(this, wifiManager.isWifiEnabled() + "δ����wifi", Toast.LENGTH_SHORT).show();
	            wifiManager.setWifiEnabled(true);
	        }
	        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
	        int ipAddress = wifiInfo.getIpAddress();
	        Log.e(TAG, "" + ipAddress);
	        //ip = intToIp(ipAddress);
	        //��ȡ���ӵ��ȵ��ip
	        DhcpInfo dhcpinfo = wifiManager.getDhcpInfo();
	        serverAddress = dhcpinfo.serverAddress;
	        ip = intToIp(serverAddress);
	        //System.out.println("serverAddress-->>" + serverAddress);
	        Log.e(TAG, ip);
			break;
		case R.id.map:
			Intent intent1=new Intent();
			intent1.setClass(this, Baidumap_Activity.class);
			intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent1);
			break;
		default:
			break;
		}
	}
}
