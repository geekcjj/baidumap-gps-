package com.maike.baidumapfzzb;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View.OnClickListener;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity implements OnClickListener {
	private Button login;
	private TextView register;
      public void onCreate(Bundle savedInstanceState){
    	  super.onCreate(savedInstanceState);
    	  /*this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
  				WindowManager.LayoutParams.FLAG_FULLSCREEN);*/
  		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
    	  setContentView(R.layout.loginactivity);
    	  init();
      }

	private void init() {
		// TODO Auto-generated method stub
		login=(Button)findViewById(R.id.login);
		register=(TextView)findViewById(R.id.register);
		login.setOnClickListener(this);
		register.setOnClickListener(this);
	}
	public void onClick(View v){
		switch(v.getId()){
		case R.id.login:
			Intent intent=new Intent();
			intent.setClass(LoginActivity.this, BaidumapActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			break;
		case R.id.register:
			Intent intent2=new Intent(LoginActivity.this, BaidumapActivity.class);
			intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent2);
			break;
		}
	}
	public boolean onKeyDown(int keyCode, KeyEvent event) {  
	    // TODO Auto-generated method stub  
	    if(keyCode == KeyEvent.KEYCODE_BACK)  
	       {    
	           exitBy2Click();      //����˫���˳�����  
	       }  
	    return false;  
	}  
	/** 
	 * ˫���˳����� 
	 */  
	private static Boolean isExit = false;  
	  
	private void exitBy2Click() {  
	    Timer tExit = null;  
	    if (isExit == false) {  
	        isExit = true; // ׼���˳�  
	        Toast.makeText(this, "�ٰ�һ���˳�����", Toast.LENGTH_SHORT).show();  
	        tExit = new Timer();  
	        tExit.schedule(new TimerTask() {  
	            @Override  
	            public void run() {  
	                isExit = false; // ȡ���˳�  
	            }  
	        }, 2000); // ���2������û�а��·��ؼ�����������ʱ��ȡ�����ղ�ִ�е�����  
	  
	    } else {
	    	/*ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);    

			manager.restartPackage(getPackageName());*/
			finish();
	    	android.os.Process.killProcess(android.os.Process.myPid());
	    	System.exit(0);
	    }  
	}
	//�������л�����
	public void onConfigurationChanged(Configuration newConfig){
		 super.onConfigurationChanged(newConfig);  
	     //newConfig.orientation��õ�ǰ��Ļ״̬�Ǻ����������   
	     //Configuration.ORIENTATION_PORTRAIT ��ʾ����   
	     //Configuration.ORIENTATION_LANDSCAPE ��ʾ����   
	     if(newConfig.orientation==Configuration.ORIENTATION_PORTRAIT){  
	         Toast.makeText(LoginActivity.this, "����������", Toast.LENGTH_SHORT).show();  
	     }  
	     if(newConfig.orientation==Configuration.ORIENTATION_LANDSCAPE){  
	         Toast.makeText(LoginActivity.this, "�����Ǻ���", Toast.LENGTH_SHORT).show();  
	     }  
	 }
}
