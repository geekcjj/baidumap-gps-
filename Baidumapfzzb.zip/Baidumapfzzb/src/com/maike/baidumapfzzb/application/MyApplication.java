package com.maike.baidumapfzzb.application;

import android.app.Application;
import android.os.Bundle;

public class MyApplication extends Application{
	private String ip;
	public void onCreate(Bundle savedInstanceState){
		
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
}
