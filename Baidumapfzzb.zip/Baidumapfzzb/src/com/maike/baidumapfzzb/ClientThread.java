package com.maike.baidumapfzzb;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.SocketTimeoutException;

import com.maike.baidumapfzzb.application.MyApplication;

import android.app.Activity;
import android.content.Context;
import android.net.DhcpInfo;
import android.net.IpPrefix;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

public class ClientThread implements Runnable{
	private static final int PORT=8899;
	private static final String TAG="ClientThread";
	private WifiManager wifiManager;
    private Socket msocket;
    //���巢����Ϣ��handler����
    private Handler handler;
    //�������UI�̵߳�handler����
    public Handler revhandler;
    public static String ip="10.10.100.254";
    private MyApplication myapp;
    DataOutputStream outstream=null;
    BufferedInputStream brinstream=null;
    BufferedReader br=null;
	private int serverAddress;
    //private String gpsstr="";
    //private String[] gpsmsg=null;
    public ClientThread(Handler handler){
    	this.handler=handler;
    }
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try{
			msocket=new Socket(ip,PORT);
			//brinstream=new BufferedInputStream(msocket.getInputStream());
			br=new BufferedReader(new InputStreamReader(msocket.getInputStream()));
			outstream =new DataOutputStream(msocket.getOutputStream());
			//����һ�����߳�����ȡ��������Ӧ������
			new Thread(){

				public void run(){
					String str = null;
					//byte[] buffer=new byte[1024];;
					//��ȡsocket���е�����brinstream.read(buffer)>0
					try{
						while((str=br.readLine())!=null){
							//brinstream.read(buffer);
							//content+=str;
							//str = new String(buffer).trim();
							
								//Log.e(TAG,gpsm[0]);
							/*gpsmsg = gpsstr.split(",");
							for(int i=0;i<=gpsmsg.length;i++){
							}
							while("$GNRMC"==gpsmsg[0]){
								return;
							}*/
					        //gps=tiqu(gpsmsg);
							//gps=gpsm[4]+gpsm[6];
							Message msg=new Message();
							msg.what=1;
							msg.obj=str;
							handler.sendMessage(msg);
					   }	
					}catch(IOException e){
						e.printStackTrace();
						Log.d(TAG, str);
					}
					
				}
			}.start();
			//Ϊ��ǰ�̳߳�ʼ��loop
			Looper.prepare();
			//����revHandler����
			revhandler=new Handler(){
				public void handleMessage(Message msg){
					if(msg.what==2){
						try{
							outstream.write(msg.obj.toString().getBytes());
						}catch(Exception e){
							e.printStackTrace();
						}
					}
				}
			};
			//����looper
			Looper.loop();
		}catch(SocketTimeoutException e1){
			Log.d(TAG, "�������ӳ�ʱ��");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void onCreate() {
		//��ȡWiFi����
        wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        int ipAddress = wifiInfo.getIpAddress();
        Log.e(TAG, "" + ipAddress);
        //ip = intToIp(ipAddress);
        //��ȡ���ӵ��ȵ��ip
        DhcpInfo dhcpinfo = wifiManager.getDhcpInfo();
        serverAddress = dhcpinfo.serverAddress;
        ip = intToIp(serverAddress);
	}
	private WifiManager getSystemService(String wifiService) {
		// TODO Auto-generated method stub
		return null;
	}
	private String intToIp(int serverAddress) {
		// TODO Auto-generated method stub
		return (serverAddress & 0xFF) + "." +
        ((serverAddress >> 8) & 0xFF) + "." +
        ((serverAddress >> 16) & 0xFF) + "." +
        (serverAddress >> 24 & 0xFF);
	}
}
