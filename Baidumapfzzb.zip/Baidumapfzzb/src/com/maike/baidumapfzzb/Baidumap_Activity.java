package com.maike.baidumapfzzb;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BaiduMap.OnMapClickListener;
import com.baidu.mapapi.map.BaiduMap.OnMarkerClickListener;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.CircleOptions;
import com.baidu.mapapi.map.InfoWindow;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.Stroke;
import com.baidu.mapapi.map.InfoWindow.OnInfoWindowClickListener;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MyLocationConfiguration.LocationMode;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeOption;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;
import com.baidu.mapapi.utils.CoordinateConverter;
import com.baidu.mapapi.utils.CoordinateConverter.CoordType;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class Baidumap_Activity extends Activity{
	    private DrawerLayout mDrawerLayout;
	    // ��λ���
		LocationClient mLocClient;
		public MyLocationListenner myListener= new MyLocationListenner();;
		private LocationMode mCurrentMode;
		BitmapDescriptor mCurrentMarker;
		//���巢����Ϣ��handler����
	    private Handler handler;
		MapView mMapView;
		BaiduMap mBaiduMap;
		//�����������ͨ�ŵ����߳�
		ClientThread clientThread;
		// UI���
		OnCheckedChangeListener radioButtonListener;
		//��������ϵ��ı���
		EditText input;
		Button requestLocButton;
		//��������ϵ�һ�����Ͱ�ť
		Button send;
		TextView jindu;
		TextView weidu;
		TextView haibatxt;
		boolean isFirstLoc = true;// �Ƿ��״ζ�λ
		private String str="";
		private String[] gpsm=null;
	    private String gpsstr="";
		private double result;
		private String temp;
		private double result1;
		private String temp1;
		private String haiba;
		//*******************************************************************
		private List<LatLng> locs=new ArrayList<LatLng>();
		private List<String> times=new ArrayList<String>();
		String sdate0;
		String sdate1;
		Date ddate0,date1;
		int timesize;
		int count;
		//�洢һ��λ�õ�ά��
		private LatLng loc;
		//��λsdk�ĺ�����
		private LocationClient mlocclient;
		//��λͼ�����ʾ��ʽ
		private LocationMode mcurrentmode;
		//bitmap ������Ϣ
		BitmapDescriptor mcurrentmarker;
		//MapStatusUpdate�����������ż���ȣ�newLatLng���õ�ͼ�����ĵ�
		MapStatusUpdate msu;
		private Button button[] = new Button[48];
		private InfoWindow infoWindow[] = new InfoWindow[48];
		private OnInfoWindowClickListener[] listener = new OnInfoWindowClickListener[48];
		private int buttonCount = 0;
		private int infCount = 0;
		private int lisCount = 0;
		Button request;
		//*********************************************************************
		LatLng sourceLatLng;
		//LatLng desLatLng;
		LatLng reslatlng=new LatLng(37.816555,120.714195);
		private Button weixin;
		private Button putong;
		private Button offline;
		private boolean isRequest=false;
		private BitmapDescriptor bitmap;
		private CheckBox hidePoiInfo = null;
		private TextView distance;
		private TextView latinfo;
		private TextView lnginfo;
		private TextView clickaddinfo;
		private Button clear;
		int len = 0;
		int length;
		private Button connect;
        public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			requestWindowFeature(Window.FEATURE_NO_TITLE);
			//getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
			//��ʹ��SDK�����֮ǰ��ʼ��context��Ϣ������ApplicationContext  
	        //ע��÷���Ҫ��setContentView����֮ǰʵ��  
	        SDKInitializer.initialize(getApplicationContext());
			setContentView(R.layout.baidumap_activity);
			requestLocButton = (Button)findViewById(R.id.button1);
			send=(Button)findViewById(R.id.sendbtn);
			weixin=(Button)findViewById(R.id.weixin);
			putong=(Button)findViewById(R.id.putong);
			offline=(Button)findViewById(R.id.offline);
			request=(Button)findViewById(R.id.request);
			clear=(Button)findViewById(R.id.clear);
			connect=(Button)findViewById(R.id.connect);
			input=(EditText)findViewById(R.id.input);
			jindu=(TextView)findViewById(R.id.jindu);
			weidu=(TextView)findViewById(R.id.weidu);
			haibatxt=(TextView)findViewById(R.id.haiba);
			distance=(TextView)findViewById(R.id.distance);
			latinfo=(TextView)findViewById(R.id.latinfo);
			lnginfo=(TextView)findViewById(R.id.lnginfo);
			clickaddinfo=(TextView)findViewById(R.id.clickaddinfo);
			hidePoiInfo = (CheckBox)findViewById(R.id.hide_poiinfo);
			mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
			mCurrentMode = LocationMode.NORMAL;
			requestLocButton.setText("��ͨ");
			handler=new Handler(){

				String gpsn="";//="33.783991666666665"
		        String gpse="";//="118.51945277777777" 
				public void handleMessage(Message msg){
					if(msg.what==1){
						str=(String) msg.obj;
						gpsstr=jiexi(str);						
						gpsm = gpsstr.split(",");
						//gpsmsg=tiqu(gpsm);
						for(int i=0;i<=gpsm.length;i++){
						
						}
						if("$GNRMC".equals(gpsm[0])){
						//�����Ϣ���������߳�
							//gpsdata=gpsm[3]+","+gpsm[5];
							gpsn=jiexi1(gpsm[3]);
						    gpse=jiexi2(gpsm[5]);
						    sourceLatLng=new LatLng(Double.parseDouble(gpsn),Double.parseDouble(gpse));
		                    reslatlng=convertGPSToBaidu(sourceLatLng);
						    weidu.setText(String.valueOf(reslatlng.latitude));
						    jindu.setText(String.valueOf(reslatlng.longitude));
						    latinfo.setText(String.valueOf(reslatlng.latitude));
			                lnginfo.setText(String.valueOf(reslatlng.longitude));						    
						}
						if("$GNGGA".equals(gpsm[0])){
							haiba=gpsm[9];
							haibatxt.setText(haiba+"��");
						}
					}
				}
			};
			connect.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					clientThread=new ClientThread(handler);
			        new Thread(clientThread).start();
				}
			});
			//weidu.getText().toString())Double.parseDouble()
			send.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					try{
						//���û��������ͺ󣬽��û���������ݷ�װ��Message
						//Ȼ��ѷ�װ�õ����ݷ��͸����̵߳�Handler
						Message msg=new Message();
						msg.what=2;
						msg.obj=input.getText().toString();
						clientThread.revhandler.sendMessage(msg);
						input.setText("");
					}catch(Exception e){
					}
				}
				
			});
			Button button = (Button) findViewById(R.id.toolbar_menu);
	        button.setOnClickListener(new OnClickListener()
	        {

	            @Override
	            public void onClick(View v)
	            {
	                // ��ť���£��������
	                mDrawerLayout.openDrawer(Gravity.RIGHT);

	            }
	        });
	        request.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					requestLocation();
				}
			});
	        offline.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent=new Intent();
					intent.setClass(Baidumap_Activity.this, Offlinemap.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(intent);
				}
			});
			OnClickListener btnClickListener = new OnClickListener() {
				@SuppressWarnings("deprecation")
				@SuppressLint("RtlHardcoded")
				public void onClick(View v) {
					switch (mCurrentMode) {
					case NORMAL:
						requestLocButton.setText("����");
						mCurrentMode = LocationMode.FOLLOWING;
						mBaiduMap
								.setMyLocationConfigeration(new MyLocationConfiguration(
										mCurrentMode, true, mCurrentMarker));
						break;
					case COMPASS:
						requestLocButton.setText("��ͨ");
						mCurrentMode = LocationMode.NORMAL;
						mBaiduMap
								.setMyLocationConfigeration(new MyLocationConfiguration(
										mCurrentMode, true, mCurrentMarker));
						break;
					case FOLLOWING:
						requestLocButton.setText("����");
						mCurrentMode = LocationMode.COMPASS;
						mBaiduMap
								.setMyLocationConfigeration(new MyLocationConfiguration(
										mCurrentMode, true, mCurrentMarker));
						break;
					}
				}
			};
			requestLocButton.setOnClickListener(btnClickListener);

			RadioGroup group = (RadioGroup) this.findViewById(R.id.radioGroup);
			radioButtonListener = new OnCheckedChangeListener() {
				@SuppressWarnings("deprecation")
				@Override
				public void onCheckedChanged(RadioGroup group, int checkedId) {
					if (checkedId == R.id.defaulticon) {
						// ����null�򣬻ָ�Ĭ��ͼ��
						mCurrentMarker = null;
						mBaiduMap
								.setMyLocationConfigeration(new MyLocationConfiguration(
										mCurrentMode, true, null));
					}
					if (checkedId == R.id.customicon) {
						// �޸�Ϊ�Զ���marker
						mCurrentMarker = BitmapDescriptorFactory
								.fromResource(R.drawable.icon_geo);
						mBaiduMap
								.setMyLocationConfigeration(new MyLocationConfiguration(
										mCurrentMode, true, mCurrentMarker));
					}
				}
			};
			//hidePoiInfo.setOnCheckedChangeListener(new HidePoiInfoListener());
			group.setOnCheckedChangeListener(radioButtonListener);
			// ��ͼ��ʼ��
			mMapView = (MapView) findViewById(R.id.bmapsView);
			mBaiduMap = mMapView.getMap();
			mBaiduMap.clear();
			//Marker marker = (Marker)mBaiduMap.addOverlay(option); 
			//marker.remove();
			 //�����Ƿ���ʾ�����߿ؼ�  
            //mMapView.showScaleControl(false);  
            //�����Ƿ���ʾ���ſؼ�  
            //mMapView.showZoomControls(false);  
            // ɾ���ٶȵ�ͼLoGo  
            mMapView.removeViewAt(1);
            // ����markerͼ��  
            bitmap = BitmapDescriptorFactory.fromResource(R.drawable.maker);  
            mBaiduMap.setOnMapClickListener(new OnMapClickListener() {
				@Override  
                public boolean onMapPoiClick(MapPoi arg0) {  
                    // TODO Auto-generated method stub
                	arg0.getName();//����
                	arg0.getPosition();//����
                    return false;  
                }
                //�˷������ǵ����ͼ����  
                @Override  
                public void onMapClick(LatLng latLng) {
                	//��ȡ��γ��  
                    double latitude = latLng.latitude;  
                    double longitude = latLng.longitude;
                    System.out.println("latitude=" + latitude + ",longitude=" + longitude);  
                    //�����ͼ��  
                    //mBaiduMap.clear();  
                    // ����Maker�����  
                    LatLng point = new LatLng(latitude, longitude);  
                    // ����MarkerOption�������ڵ�ͼ������Marker  
                    MarkerOptions options = new MarkerOptions().position(point)  
                            .icon(bitmap);  
                    // �ڵ�ͼ������Marker������ʾ  
                    mBaiduMap.addOverlay(options);
                    //if(isfirstclick=true){
                    onDrawView(point);
                    /*}else{
                    	onDrawView2(point);
                    }*/
        			String lat=(String) latinfo.getText();
        			String lng=(String) lnginfo.getText();
                    double cc= Distance(Double.parseDouble(lat),Double.parseDouble(lng),point.latitude,point.longitude); 
					length=(int)cc;
					len+=length;
					distance.setText("�滮��ʻ·��:"+(len/1000)+"."+(len%1000)+"ǧ��");
					latinfo.setText(String.valueOf(latitude));
        			lnginfo.setText(String.valueOf(longitude));
					//ʵ����һ�����������ѯ����
                    GeoCoder geoCoder = GeoCoder.newInstance();  
                    //���÷���������λ������  
                    ReverseGeoCodeOption op = new ReverseGeoCodeOption();  
                    op.location(latLng);
                    //���𷴵�����������(��γ��->��ַ��Ϣ)  
                    geoCoder.reverseGeoCode(op);  
                    geoCoder.setOnGetGeoCodeResultListener(new OnGetGeoCoderResultListener() {  
                          
                        private String address;

						public void onGetReverseGeoCodeResult(ReverseGeoCodeResult arg0) {  
                            //��ȡ����������ַ  
                            address = arg0.getAddress();
                            clickaddinfo.setText("��ϸ��ַ:"+address); 
                        }  
                          
                        public void onGetGeoCodeResult(GeoCodeResult arg0) {  
                        }  
                    });  
                }
            });
            clear.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					clearClick();
					latinfo.setText(String.valueOf(reslatlng.latitude));
					lnginfo.setText(String.valueOf(reslatlng.longitude));
					distance.setText("��ǰ·��:"+0);
					length=0;
				}
			});
            //���Marker������ַ����  
            mBaiduMap.setOnMarkerClickListener(new OnMarkerClickListener() {  
      
                @Override  
                public boolean onMarkerClick(Marker arg0) {  
                    // TODO Auto-generated method stub
                	// ����Բ
        	        LatLng llCircle = new LatLng(arg0.getPosition().latitude, arg0.getPosition().longitude);
        	        OverlayOptions ooCircle = new CircleOptions().fillColor(0x000000FF)
        	                .center(llCircle).stroke(new Stroke(5, 0xAA000000))
        	                .radius(300);
        	        mBaiduMap.addOverlay(ooCircle);
                	latinfo.setText(String.valueOf(arg0.getPosition().latitude));
        			lnginfo.setText(String.valueOf(arg0.getPosition().longitude));
                    double cc= Distance(reslatlng.latitude,reslatlng.longitude,arg0.getPosition().latitude,arg0.getPosition().longitude); 
					int length=(int)cc;
					distance.setText((length/1000+"."+length%1000)+"��");
                    return true;  
                }  
            });
			putong.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					//��ͨ��ͼ
					mBaiduMap.setMapType(BaiduMap.MAP_TYPE_NORMAL); 
				}
			});
			weixin.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					//���ǵ�ͼ    
			        mBaiduMap.setMapType(BaiduMap.MAP_TYPE_SATELLITE);
				}
			});
			// ������λͼ��
			mBaiduMap.setMyLocationEnabled(true);
			// ��λ��ʼ��
			mLocClient = new LocationClient(this);
			mLocClient.registerLocationListener(myListener);
			LocationClientOption option = new LocationClientOption();
			option.setOpenGps(true);// ��gps
			option.setCoorType("bd09ll"); // ������������
			option.setScanSpan(1000);
			mLocClient.setLocOption(option);
			mLocClient.start(); 
		}
		public static LatLng convertGPSToBaidu(LatLng sourceLatLng) {
	        // ��GPS�豸�ɼ���ԭʼGPS����ת���ɰٶ�����  
	        CoordinateConverter converter  = new CoordinateConverter();  
	        converter.from(CoordType.GPS);  
	        // sourceLatLng��ת������  
	        converter.coord(sourceLatLng);
	        LatLng desLatLng = converter.convert();
		    return desLatLng;
	    }
		/**
		 * ��λSDK��������
		 */
		public class MyLocationListenner implements BDLocationListener {

			private LatLng ll;
			@SuppressWarnings("deprecation")
			@Override
			public void onReceiveLocation(BDLocation location) {
				// map view ���ٺ��ڴ����½��յ�λ��
				if (location == null || mMapView == null)
					return;
				MyLocationData locData = new MyLocationData.Builder()
						.accuracy(location.getRadius())//��trycatch
						// �˴����ÿ����߻�ȡ���ķ�����Ϣ��˳ʱ��0-360
						.direction(100).latitude(reslatlng.latitude)
						.longitude(reslatlng.longitude).build();//reslatlng.latitudereslatlng.longitude
				mBaiduMap.setMyLocationData(locData);
				
				if (isFirstLoc) {
					isFirstLoc = false;
					ll = new LatLng(reslatlng.latitude,
							reslatlng.longitude);//Double.parseDouble(gpsn)Double.parseDouble(gpse)
					MapStatus.Builder builder = new MapStatus.Builder();
	                builder.target(ll).zoom(20.0f);
					mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(builder.build()));
				}
				location.getTime();
				//�ֶ���λ����ǰλ��
				if (isFirstLoc || isRequest) {
					msu = MapStatusUpdateFactory.newLatLng(ll);
					mBaiduMap.animateMapStatus(msu);
					isRequest = false;
				}
				isFirstLoc = false;
				//λ�÷����仯��ʼ����
				if(locs.isEmpty()){
					//llend=new LatLng(reslatlng.latitude,reslatlng.longitude);
					locs.add(ll);
					times.add(location.getTime());
			        //���ӳ�ʼ���־
					// ��ʼ��ȫ�� bitmap ��Ϣ������ʱ��ʱ recycle
					BitmapDescriptor bdA = BitmapDescriptorFactory.fromResource(R.drawable.icon_st);
					OverlayOptions firstLocMark = new MarkerOptions().position(ll).icon(bdA).zIndex(12).draggable(true);
					mBaiduMap.addOverlay(firstLocMark);
				}
				else{
					count = locs.size();
					if(locs.get(count-1)!=ll){
						new LatLng(reslatlng.latitude,reslatlng.longitude);
						locs.add(ll);
						times.add(location.getTime());
						//λ���ƶ���������֮�����
						OverlayOptions ooPolyline = new PolylineOptions().width(8).color(Color.GREEN).points(locs);
						//�ϸ�λ�õ�ʱ���ȥ���λ�õ�ʱ�䣬����֮���ʱ���ֵ����30������ͼ��
						SimpleDateFormat sdatetod = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
						timesize = times.size();
						sdate0 = times.get(timesize-1);
						sdate1 = times.get(timesize-2);
						try {
							ddate0 = sdatetod.parse(sdate0);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						try {
							date1 = sdatetod.parse(sdate1);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						if(date1.getSeconds()-ddate0.getSeconds()>5){
							//�����ӵĲ�ֵ����һ��λ�õ�λ����Ϣ���ݵ������в���ʾ�ڵ�ͼ�У����ݵ�������
							int diff=date1.getSeconds()-ddate0.getSeconds();
                            //Button button = new Button(getApplicationContext());
                            //button[buttonCount].setBackgroundResource(R.drawable.popup);
							button[buttonCount].setText("�����ڴ˴�ͣ��:"+diff+"��");
							int black =  getResources().getColor(R.drawable.icon_en);
							button[buttonCount].setTextColor(black);
							button[buttonCount].setTextSize(10);
							//infoWindow[infCount] = new InfoWindow(button[buttonCount++], locs.get(count-2), listener[lisCount++]);
							mBaiduMap.showInfoWindow(infoWindow[infCount++]);
						}
						mBaiduMap.addOverlay(ooPolyline);
					}
				}

			}

			public void onReceivePoi(BDLocation poiLocation) {
			}

			public void onConnectHotSpotMessage(String arg0, int arg1) {
				// TODO Auto-generated method stub
				
			}
		}
		/*
		 * �ֶ�����λ�ķ���
		 */
		protected void requestLocation() {
			// TODO Auto-generated method stub
			isRequest=true;
			if(mLocClient!=null&&mLocClient.isStarted()){
				//��������ķ�����ʾ���ڶ�λ
				Toast.makeText(Baidumap_Activity.this,"���ڶ�λ��������",Toast.LENGTH_SHORT).show();
				//��λ�����ReceiveListener�ķ���OnReceive�����Ĳ����з��ء�
				mLocClient.requestLocation();
			}else{
				//d����debug�ڿ���̨�������
				Log.d("LocSDK3","locClient is null or not started");
			}
		}
		public void onDrawView(LatLng arg0) {
			//����һ������ 
			String lat=(String) latinfo.getText();
			String lng=(String) lnginfo.getText();
			LatLng pt1 = new LatLng(Double.parseDouble(lat),Double.parseDouble(lng)); 
			LatLng position = new LatLng(arg0.latitude, 
					arg0.longitude);
			List<LatLng> pts = new ArrayList<LatLng>();
			pts.add(pt1);
			if (pts.size() == 0) {
				pts.add(pt1);
				pts.add(position);
				}
			if (position.latitude != (pts.get(pts.size() - 1).latitude)
				&& position.longitude != pts.get(pts.size() - 1).longitude) {
				pts.add(pt1);
				pts.add(position);
				}
			Toast.makeText(Baidumap_Activity.this,"��γ��" + position, Toast.LENGTH_SHORT).show();
			if (pts.size() >= 2) { 
			OverlayOptions polylineOption = new PolylineOptions().width(10) 
			.color(Color.BLUE).points(pts); 
			// �ڵ�ͼ�����Ӷ����Option��������ʾ 
			mBaiduMap.addOverlay(polylineOption); 
			} else { 
			Toast.makeText(Baidumap_Activity.this, "û��λ��", Toast.LENGTH_SHORT).show(); 
			}
		}
		/*protected void onDrawView2(LatLng arg1) {
			// TODO Auto-generated method stub
			//����һ������ 
			String gpsinfo[]=((String) clickgpsinfo.getText()).split(",");
			for(int i=0;i<gpsinfo.length;i++){
				
			}
			LatLng pt1 = new LatLng(Double.parseDouble(gpsinfo[0]),Double.parseDouble(gpsinfo[1])); 
			LatLng position = new LatLng(arg1.latitude, 
					arg1.longitude);
			List<LatLng> pts = new ArrayList<LatLng>();
			pts.add(pt1);
			pts.add(position);
			if (pts.size() == 0) {
				pts.add(pt1);
				pts.add(position);
				}
			if (position.latitude != (pts.get(pts.size() - 1).latitude)
					&& position.longitude != pts.get(pts.size() - 1).longitude) {
					pts.add(pt1);
					pts.add(position);
					OverlayOptions polylineOption = new PolylineOptions().width(5) 
							.color(Color.BLUE).points(pts);
					mBaiduMap.addOverlay(polylineOption);
					}
			if (pts.size() >= 2) { 
				OverlayOptions polylineOption = new PolylineOptions().width(5) 
				.color(Color.BLUE).points(pts); 
				// �ڵ�ͼ�����Ӷ����Option��������ʾ 
				mBaiduMap.addOverlay(polylineOption); 
				} else { 
				Toast.makeText(Baidumap_Activity.this, "û��λ��", Toast.LENGTH_SHORT).show(); 
				}
		}*/
		public void clearClick() {
	        // �������ͼ��
	        mMapView.getMap().clear();
	    }
//%%%%%%%%%%%%%%%%�ٶȵ�ͼapi��ش���·��:E:\�¼Ӽ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//����γ��
		protected String jiexi1(String str) {
			// TODO Auto-generated method stub
			try{
			String n1=str.substring(0, 2);//��ȡ2λ��γ�ȹ�2λ�����90��  
            String n2=str.substring(2, str.length());  
            result1 = Double.parseDouble(n1);  
            result1 += (Double.parseDouble(n2) / 60.0);  
            temp1 = String.valueOf(result1);  
            if (temp1.length() > 8) {  
                temp1 = n1 + temp1.substring(temp1.indexOf("."), 8);  
            }
            }catch(Exception e){
            	e.printStackTrace();
            }
			return temp1; 
			
		}
		//��������
		protected String jiexi2(String str) {
			// TODO Auto-generated method stub
			try{
			String e1=str.substring(0, 3);//��ȡ3λ���־��ȹ���λ�����180��,������һ�׶�Ϊ�����ϱ���������Ϊ0��,����������������180��   
            String e2=str.substring(3, str.length());//��Ҫ�����С��  
            result = Double.parseDouble(e1);  
            result += (Double.parseDouble(e2) / 60.0);  
            temp = String.valueOf(result);  
            if (temp.length() > 9) {  
                temp = e1 + temp.substring(temp.indexOf("."), 9);  
            }  
			}catch(Exception e){
            	e.printStackTrace();
            }
			return temp;
		}
		//����GPS����
		protected String jiexi(String str) {
			// TODO Auto-generated method stub
			 if (null == str || str.equals("")) {
				    System.out.println("GPS����Ϊ�գ����飡");
			        //Toast.makeText(this, "GPS����Ϊ�գ����飡", Toast.LENGTH_SHORT).show();
			        return str;
			    } else {
			        int b = str.indexOf('$');//��һ�����С�$��λ��
			        if (-1 != b) {
			            while(-1 != b && '$' == str.charAt(b)) {
			                String temp = str.substring(b,
			                        b + 6);
			                if ("$GNRMC".equals(temp)) {
			                    int e = str.indexOf('*', b);
			                    str= str.substring(b,
			                            e + 1);
			                    System.out.println(str);
			                    //parserGPSItem(gpsStr);//�������gps itemҵ�񣨴���δ������
			                    b =str.indexOf('$', e);
			                }else{
			                    b =str.indexOf('$', b+1);
			                }
			            }
			        }else{
			        	System.out.println("�����в�����$GNRMC���ݣ�");
			        	//Toast.makeText(this, "GPS����Ϊ�գ����飡", Toast.LENGTH_SHORT).show();
			        }
			    }
			return str;
		}
		public Double Distance(double lat1, double lng1,double lat2, double lng2) {  
		       
		       
		     Double R=6370996.81;  //����İ뾶  
		       
		    /* 
		     * ��ȡ�����x,y��֮��ľ��� 
		     */  
		    Double x = (lng2 - lng1)*Math.PI*R*Math.cos(((lat1+lat2)/2)*Math.PI/180)/180;  
		    Double y = (lat2 - lat1)*Math.PI*R/180;  
		  
		  
		     Double distance = Math.hypot(x, y);   //�õ�����֮���ֱ�߾���  
		           
		   return   distance;  
		           
		 } 
		@Override
		protected void onPause() {
			mMapView.onPause();
			super.onPause();
		}

		@Override
		protected void onResume() {
			mMapView.onResume();
			super.onResume();
		}

		@Override
		protected void onDestroy() {
			// �˳�ʱ���ٶ�λ
			mLocClient.stop();
			// �رն�λͼ��
			mBaiduMap.setMyLocationEnabled(false);
			mMapView.onDestroy();
			mMapView = null;
			super.onDestroy();
		}
		protected void onSaveInstanceState(Bundle outState){
			super.onSaveInstanceState(outState);
			//mMapView.onSaveInstanceState();
		}
		protected void onRestoreInstanceState(Bundle savedInstanceState) {  
	        super.onRestoreInstanceState(savedInstanceState);  
	        //mMapView.onSaveInstanceState();  
	    } 
}
