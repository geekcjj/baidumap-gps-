package com.maike.baidumapfzzb;

import java.util.ArrayList;

import com.baidu.mapapi.map.offline.MKOLSearchRecord;
import com.baidu.mapapi.map.offline.MKOLUpdateElement;
import com.baidu.mapapi.map.offline.MKOfflineMap;
import com.baidu.mapapi.map.offline.MKOfflineMapListener;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Offlinemap extends Activity implements MKOfflineMapListener {
            private MKOfflineMap moffline=null;
            private TextView cidview;
            private TextView stateview;
            private EditText citynameview;
            //�����ص����ߵ�ͼ��Ϣ
            private ArrayList<MKOLUpdateElement> localMapList =null;
            private LocalMapAdapter lAdapter =null;
            protected void onCreate(Bundle savedInstanceState){
            	super.onCreate(savedInstanceState);
            	setContentView(R.layout.offlinemap_activity);
            	moffline=new MKOfflineMap();
            	moffline.init(this);
            	initView();
            }
            private void initView() {

                cidview = (TextView) findViewById(R.id.cityid);
                citynameview = (EditText) findViewById(R.id.city);
                stateview = (TextView) findViewById(R.id.state);

                ListView hotCityList = (ListView) findViewById(R.id.hotcitylist);
                ArrayList<String> hotCities = new ArrayList<String>();
                // ��ȡ���ֳ����б�
                ArrayList<MKOLSearchRecord> records1 = moffline.getHotCityList();
                if (records1 != null) {
                    for (MKOLSearchRecord r : records1) {
                        hotCities.add(r.cityName + "(" + r.cityID + ")" + "   --"
                                + this.formatDataSize(r.size));
                    }
                }
                ListAdapter hAdapter = (ListAdapter) new ArrayAdapter<String>(this,
                        android.R.layout.simple_list_item_1, hotCities);
                hotCityList.setAdapter(hAdapter);

                ListView allCityList = (ListView) findViewById(R.id.allcitylist);
                // ��ȡ����֧�����ߵ�ͼ�ĳ���
                ArrayList<String> allCities = new ArrayList<String>();
                ArrayList<MKOLSearchRecord> records2 = moffline.getOfflineCityList();
                if (records1 != null) {
                    for (MKOLSearchRecord r : records2) {
                        allCities.add(r.cityName + "(" + r.cityID + ")" + "   --"
                                + this.formatDataSize(r.size));
                    }
                }
                ListAdapter aAdapter = (ListAdapter) new ArrayAdapter<String>(this,
                        android.R.layout.simple_list_item_1, allCities);
                allCityList.setAdapter(aAdapter);

                LinearLayout cl = (LinearLayout) findViewById(R.id.citylist_layout);
                LinearLayout lm = (LinearLayout) findViewById(R.id.localmap_layout);
                lm.setVisibility(View.GONE);
                cl.setVisibility(View.VISIBLE);

                // ��ȡ���¹������ߵ�ͼ��Ϣ
                localMapList = moffline.getAllUpdateInfo();
                if (localMapList == null) {
                    localMapList = new ArrayList<MKOLUpdateElement>();
                }

                ListView localMapListView = (ListView) findViewById(R.id.localmaplist);
                lAdapter = new LocalMapAdapter();
                localMapListView.setAdapter(lAdapter);

            }

            /**
             * �л��������б�
             *
             * @param view
             */
            public void clickCityListButton(View view) {
                LinearLayout cl = (LinearLayout) findViewById(R.id.citylist_layout);
                LinearLayout lm = (LinearLayout) findViewById(R.id.localmap_layout);
                lm.setVisibility(View.GONE);
                cl.setVisibility(View.VISIBLE);

            }

            /**
             * �л������ع����б�
             *
             * @param view
             */
            public void clickLocalMapListButton(View view) {
                LinearLayout cl = (LinearLayout) findViewById(R.id.citylist_layout);
                LinearLayout lm = (LinearLayout) findViewById(R.id.localmap_layout);
                lm.setVisibility(View.VISIBLE);
                cl.setVisibility(View.GONE);
            }

            /**
             * ������������
             *
             * @param view
             */
            public void search(View view) {
                ArrayList<MKOLSearchRecord> records = moffline.searchCity(citynameview
                        .getText().toString());
                if (records == null || records.size() != 1) {
                    return;
                }
                cidview.setText(String.valueOf(records.get(0).cityID));
            }

            /**
             * ��ʼ����
             *
             * @param view
             */
            public void start(View view) {
                int cityid = Integer.parseInt(cidview.getText().toString());
                moffline.start(cityid);
                clickLocalMapListButton(null);
                Toast.makeText(this, "��ʼ�������ߵ�ͼ. cityid: " + cityid, Toast.LENGTH_SHORT)
                        .show();
                updateView();
            }

            /**
             * ��ͣ����
             *
             * @param view
             */
            public void stop(View view) {
                int cityid = Integer.parseInt(cidview.getText().toString());
                moffline.pause(cityid);
                Toast.makeText(this, "��ͣ�������ߵ�ͼ. cityid: " + cityid, Toast.LENGTH_SHORT)
                        .show();
                updateView();
            }

            /**
             * ɾ�����ߵ�ͼ
             *
             * @param view
             */
            public void remove(View view) {
                int cityid = Integer.parseInt(cidview.getText().toString());
                moffline.remove(cityid);
                Toast.makeText(this, "ɾ�����ߵ�ͼ. cityid: " + cityid, Toast.LENGTH_SHORT)
                        .show();
                updateView();
            }

            /**
             * ����״̬��ʾ
             */
            public void updateView() {
                localMapList = moffline.getAllUpdateInfo();
                if (localMapList == null) {
                    localMapList = new ArrayList<MKOLUpdateElement>();
                }
                lAdapter.notifyDataSetChanged();
            }

            @Override
            protected void onPause() {
                int cityid = Integer.parseInt(cidview.getText().toString());
                MKOLUpdateElement temp = moffline.getUpdateInfo(cityid);
                if (temp != null && temp.status == MKOLUpdateElement.DOWNLOADING) {
                    moffline.pause(cityid);
                }
                super.onPause();
            }

            @Override
            protected void onResume() {
                super.onResume();
            }

            public String formatDataSize(int size) {
                String ret = "";
                if (size < (1024 * 1024)) {
                    ret = String.format("%dK", size / 1024);
                } else {
                    ret = String.format("%.1fM", size / (1024 * 1024.0));
                }
                return ret;
            }

            @Override
            protected void onDestroy() {
                /**
                 * �˳�ʱ���������ߵ�ͼģ��
                 */
                moffline.destroy();
                super.onDestroy();
            }

            @Override
            public void onGetOfflineMapState(int type, int state) {
                switch (type) {
                    case MKOfflineMap.TYPE_DOWNLOAD_UPDATE: {
                        MKOLUpdateElement update = moffline.getUpdateInfo(state);
                        // �������ؽ��ȸ�����ʾ
                        if (update != null) {
                            stateview.setText(String.format("%s : %d%%", update.cityName,
                                    update.ratio));
                            updateView();
                        }
                    }
                        break;
                    case MKOfflineMap.TYPE_NEW_OFFLINE:
                        // �������ߵ�ͼ��װ
                        Log.d("OfflineDemo", String.format("add offlinemap num:%d", state));
                        break;
                    case MKOfflineMap.TYPE_VER_UPDATE:
                        // �汾������ʾ
                        // MKOLUpdateElement e = mOffline.getUpdateInfo(state);

                        break;
                    default:
                        break;
                }

            }

            /**
             * ���ߵ�ͼ�����б�������
             */
            public class LocalMapAdapter extends BaseAdapter {

                @Override
                public int getCount() {
                    return localMapList.size();
                }

                @Override
                public Object getItem(int index) {
                    return localMapList.get(index);
                }

                @Override
                public long getItemId(int index) {
                    return index;
                }

                @SuppressLint("ViewHolder")
				@Override
                public View getView(int index, View view, ViewGroup arg2) {
                    MKOLUpdateElement e = (MKOLUpdateElement) getItem(index);
                    view = View.inflate(Offlinemap.this,
                            R.layout.offline_localmap_list, null);
                    initViewItem(view, e);
                    return view;
                }

                void initViewItem(View view, final MKOLUpdateElement e) {
                    Button remove = (Button) view.findViewById(R.id.remove);
                    TextView title = (TextView) view.findViewById(R.id.title);
                    TextView update = (TextView) view.findViewById(R.id.update);
                    TextView ratio = (TextView) view.findViewById(R.id.ratio);
                    ratio.setText(e.ratio + "%");
                    title.setText(e.cityName);
                    if (e.update) {
                        update.setText("�ɸ���");
                    } else {
                        update.setText("����");
                    }

                    remove.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View arg0) {
                            moffline.remove(e.cityID);
                            updateView();
                        }
                    });
                }

            }

}
